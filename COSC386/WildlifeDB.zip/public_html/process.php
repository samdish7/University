
<?php
	session_start();
	include("secure.php");

	$db = mysqli_connect('localhost','sdisharoon1','sdisharoon1','WildLifeDB');
	session_start();

	if(isset($_POST['btn'])){
		echo'Working';
	}
	else{
		header('Location: secure.php');
	}
 
?>
