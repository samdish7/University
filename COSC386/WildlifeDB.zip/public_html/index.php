<html><body>
	<form method=post action="test.php">
		<p>
			<label>Column:</label>
			<input type="text" id="column" name="column"></input> </p>
		<p>
			<input type="submit" id="btn" value="Enter column name"/></input>
		</p>
	</form>
</body>
</html>
