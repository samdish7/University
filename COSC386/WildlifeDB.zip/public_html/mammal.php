<!DOCTYPE html>
<html lang="en">
<head>
<title>Chesapeake Bay Mammals</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>                                     
* {
	box-sizing: border-box;
	font-family: Arial, Helvetica, sans-serif;
}
body {
	margin: 0;
	font-family: Arial, Helvetica, sans-serif;
}
/* Style the top navigation bar */
.topnav {
	font-family: Arial, Helvetica, sans-serif;
	overflow: hidden;
	background-color: blue;
}
/* Style the topnav links */
.topnav a {
	float: left;
	display: block;
	color: white;
	text-align: center;
	padding: 14px 16px;
	text-decoration: none;
}
/* Change color on hover */
.topnav a:hover {
	background-color: white;
	color: black;
}
/* Style the content */
.content {
	background-color: white;
}
/* Style the footer */
.footer {
	font-family: Arial, Helvetica, sans-serif;
	background-color: blue;
	color: white;
	padding: 5px;
}
/*table style*/
table{
	margin: 8px;
}
th{
	font-family: Arial, Helvetica, sans-serif;
}
td{
	font-family: Arial, Helvetica, sans-serif;
	border: 2px solid #999966;
}
</style>
</head>
<body>
<div class="topnav">
	<a href="index.html">Home</a>
	<a href="mammal.php">Mammals</a>
	<a href="bird.php">Birds</a>
	<a href="aquatic.php">Aquatic Life</a>
	<a href="showData.php">Search</a>
	<a href="secure.php">Login</a>
</div>
<?php
$servername = "localhost";
$username = "kbradshaw3";
$password = "kbradshaw3";
$dbname = "WildLifeDB";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if(!$conn){
	die("Connection Failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM Mammals";
$result = mysqli_query($conn, $sql);

echo "<table>";
echo "<tr><th style ='width: 100px;'> Mammal ID </th><th style = 'width: 100px;'> Scientific Name </th><th style= 'width: 100px;'> Number of Legs </th><th style= 'width: 100px;'> Opposable Thumbs </th></tr>";

while($row=mysqli_fetch_array($result)){
	$mammalid = $row["mammalID"];
	$sname = $row["scientificName"];
	$numlegs = $row["numLegs"];
	$thumbs = $row["opposableThumbs"];
	echo "<tr><td style= 'width: 200 px;'>".$mammalid."</td><td style = 'width: 200px;'>".$sname."</td><td style = 'width: 200px;'>".$numlegs."</td><td style = 'width: 200px;'>".$thumbs."</td></tr>";
}
echo "</table>";
mysqli_close();

?>
</body>
<footer>
<div class="footer">
<p>&copy Kathleen Bradshaw, Sam Disharoon, Mason Kimbell, Jordan Welch</p>
</div></footer>
</html>
