<html><body>
	<form method=post action="testInsert.php">
		<p>
			<label>Year:</label>
			<input type="text" id="year" name="year"></input> </p>
		<p>
			<label>Winner:</label>
			<input type="text" id="winner" name="winner"></input> </p>	
		<p>
			<label>Loser:</label>
			<input type="text" id="loser" name="loser"></input> </p>
		<p>
			<input type="submit" id="btn" value="Submit Info"/></input>
		</p>
	</form>
</body>
</html>
