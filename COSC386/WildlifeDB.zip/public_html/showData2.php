<!DOCTYPE html>
<html lang="en">
<Title>Results</Title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
}
body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
}
/* Style the top navigation bar */
.topnav {
        font-family: Arial, Helvetica, sans-serif;
        overflow: hidden;
        background-color: blue;
}
/* Style the topnav links */
.topnav a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
}
/* Change color on hover */
.topnav a:hover {
        background-color: white;
        color: black;
}
/* Style the content */
.content {
        background-color: white;
}
/* Style the footer */
.footer {
        font-family: Arial, Helvetica, sans-serif;
        background-color: blue;
        color: white;
        padding: 5px;
}
/*table style*/
table{
        margin: 8px;
}
th{
        font-family: Arial, Helvetica, sans-serif;
}
td{
        font-family: Arial, Helvetica, sans-serif;
        border: 2px solid #999966;
}
</style>
</head>
<body>
<div class="topnav">
        <a href="index.html">Home</a>
        <a href="mammal.php">Mammals</a>
        <a href="bird.php">Birds</a>
        <a href="aquatic.php">Aquatic Life</a>
        <a href="showData.php">Search</a>
        <a href="secure.php">Login</a>
</div>

<?php
if($connection=@mysqli_connect('localhost','mkimbell1','mkimbell1','WildLifeDB')){
	//	print '<p>successfully connected to MySQL</p>';
	;
}else{
	die('<p>could not connect to MySQL</p>');
}

$type = $_POST['radio'];

$attrSelection = $_POST['attr'];
if(empty($attrSelection)){
	//echo "did not select any attributes";
	$attrlist = "* ";
}else{
	$n = count($attrSelection);
	//echo "you selected:</br>";
	for($i=0; $i < $n; $i++){
		if($attrSelection[$i] == "scientificName"){
			$attrSelection[$i] = "w.".$attrSelection[$i];
		}
	//	echo($attrSelection[$i]."</br>");
		if(!empty($attrlist))
			$attrlist = $attrlist.", ".$attrSelection[$i];
		else
			$attrlist = $attrSelection[$i];
	}
}

//echo "attribute list: ".$attrlist."</br>";

$selectFrom="SELECT DISTINCT ".$attrlist." FROM Wildlife w join LivesIn l on w.scientificName = l.scientificName join Eats e on w.scientificName = e.predSName "; 

$searchFor = $_POST['radio2'];
//echo "searching for ".$searchFor."...</br>";
$value = $_POST['searchFor'];
if(empty($value)){
	$where = ";";
}
else if($searchFor == "lifespan" || $searchFor == "size"){
	$where = "where ";
	$where = $where.$searchFor." = ".$value.";";
}else if($searchFor == "endangeredStatus" || $searchFor == "birthProcess" || $searchFor == "feedYoung"){
	$where = "where ";
	$where = $where.$searchFor." = '".$value."';";
}else{
	$where = "where ";
	$where = $where.$searchFor." like '% ".$value." %' or "
		.$searchFor." like '% ".$value."' or "
		.$searchFor." like '".$value." %' or "
		.$searchFor." like '".$value."';";
}

$query = $selectFrom." ".$where;

//echo $query;

if($type=="AquaticLife"){
	$attr = array("aquaticID", "vertebraeType", "scientificName");
}else if($type=="Birds"){
	$attr = array("wingspan", "birdID", "scientificName");
}else if($type=="Mammals"){
	$attr = array("mammalID", "opposableThumbs", "numLegs", "scientificName");
}else{
	$attr = array("lifespan", "endangeredStatus", "birthProcess", "feedYoung", "scientificName", "size", "commonName", "population", "preySName", "region", "habitat");
}

for($i=0; $i < $n; $i++){
	if($attrSelection[$i] == "w.scientificName")
		$attrSelection[$i] = "scientificName";
}

if(empty($attrSelection))
	$attrSelection = $attr;

$r = mysqli_query($connection, $query);
	echo "<table border='1' cellpadding='15'>
		<thead>
		<tr>";
		foreach($attrSelection as $a){
			echo "<th>".$a."</th>";
		}
		echo "</tr>
	</thead>";
while($row=mysqli_fetch_array($r)){
	echo"<tr style='background-color:#aaaaa0'>";
	foreach($attrSelection as $b){
		echo "<td>".$row[$b]."</td>";
	}
	echo"</tr>";
}
echo"</table>";
 
mysqli_close($connection);
?>
</body>
<footer>
<div class="footer">
<p>&copy Kathleen Bradshaw, Sam Disharoon, Mason Kimbell, Jordan Welch</p>
</div>
</footer>
</html>
