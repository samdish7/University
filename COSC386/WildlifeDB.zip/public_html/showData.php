<!DOCTYPE html>
<html lang="en">
<head>
<title>Data</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
}
body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
}
/* Style the top navigation bar */
.topnav {
        font-family: Arial, Helvetica, sans-serif;
        overflow: hidden;
        background-color: blue;
}
/* Style the topnav links */
.topnav a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
	text-decoration: none;
}
/* Change color on hover */
.topnav a:hover {
        background-color: white;
        color: black;
}
/* Style the content */
.content {
        background-color: white;
}
/* Style the footer */
.footer {
        font-family: Arial, Helvetica, sans-serif;
        background-color: blue;
        color: white;
        padding: 5px;
}
/*table style*/
table{
        margin: 8px;
}
th{
        font-family: Arial, Helvetica, sans-serif;
}
td{
        font-family: Arial, Helvetica, sans-serif;
        border: 2px solid #999966;
}
</style>
</head>
<body>
<div class="topnav">
        <a href="index.html">Home</a>
        <a href="mammal.php">Mammals</a>
        <a href="bird.php">Birds</a>
        <a href="aquatic.php">Aquatic Life</a>
        <a href="showData.php">Search</a>
        <a href="secure.php">Login</a>
</div>

	<form method=post action="showData2.php">
		<p>
			<label>Select attribute to search:<br></label>
			<input type="radio" name="radio2" value="lifespan">Lifespan<br></input>
			<input type="radio" name="radio2" value="endangeredStatus">Endangered Status<br></input>
			<input type="radio" name="radio2" value="birthProcess">Birth Process<br></input>
			<input type="radio" name="radio2" value="feedYoung">Feed Young<br></input>
			<input type="radio" name="radio2" value="w.scientificName">Scientific Name<br></input>
			<input type="radio" name="radio2" value="size">Size<br></input>
			<input type="radio" name="radio2" value="commonName">Common Name<br></input>
			<input type="radio" name="radio2" value="preySName">Prey<br></input>
			<input type="radio" name="radio2" value="region">Region<br></input>
			<input type="radio" name="radio2" value="habitat">Habitat<br></input>

			<label>Enter Search Value:<br></label>
			<input type="text" id="searchFor" name="searchFor"></input>

			<br><br>

			<label>Select data to show:<br></label>
			<input type="checkbox" name="attr[]" value="lifespan">Lifespan<br></input>
			<input type="checkbox" name="attr[]" value="endangeredStatus">Endangered Staus<br></input>
			<input type="checkbox" name="attr[]" value="birthProcess">Birth Process<br></input>
			<input type="checkbox" name="attr[]" value="feedYoung">Feed Young<br></input>
			<input type="checkbox" name="attr[]" value="scientificName">Scientific Name<br></input>
			<input type="checkbox" name="attr[]" value="size">Size<br></input>
			<input type="checkbox" name="attr[]" value="commonName">Common Name<br></input>
			<input type="checkbox" name="attr[]" value="preySName">Prey<br></input>
			<input type="checkbox" name="attr[]" value="region">Region<br></input>
			<input type="checkbox" name="attr[]" value="habitat">Habitat<br></input>

			<br><br>

			<input type="submit" id="btn" value="Search"></input>
		</p>
	</form>
</body>
<footer>
<div class="footer">
<p>&copy Kathleen Bradshaw, Sam Disharoon, Mason Kimbell, Jordan Welch</p>
</div>
</footer>
</html>
