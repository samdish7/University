<html><body>
	<form method=post action="pres.php">
		<p>
			<input type="submit"></input>
	
		</p>
	</form>
</body>
</html>
