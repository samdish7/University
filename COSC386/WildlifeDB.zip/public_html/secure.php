<!DOCTYPE HTML>
<html>
<head>
<title>Home</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;                                 }

body {
        margin: 0;
        font-family: Arial, Helvetica, sans-serif;
}

/* Style the top navigation bar */
.topnav {
        overflow: hidden;
        background-color: blue;
}

/* Style the topnav links */
.topnav a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
/* Change color on hover */
}
.topnav a:hover {
        background-color: white;
        color: black;
}

/* Style the content */
.content {
        background-color: white;
}

/* Style the footer */
.footer {
        background-color: blue;
        color: white;
        padding: 5px;
}
.column {
        float: left;
        width: 33.33%;
        padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
        content: "";
        clear: both;
        display: table;
}
.info {
        background-color: black;
        color: white;
        padding: 5px;
}
.head {
        background-color: black;
        color: white;
        padding: 5px;
}
</style>
</head>
	<body>
	<div class="topnav">
	<a href="index.html">Home</a>
	<a href="mammal.php">Mammals</a>
	<a href="bird.php">Birds</a>
	<a href="aquatic.php">Aquatic Life</a>
	<a href="showData.php">Search</a>
	<a href="secure.php">Login</a>
	</div>	
		<form action="insert.php" method="post">
			<label>Username:</label><br/>
			<input type="text" id = "user" name="Username"><br/>
			<label>Password:</label><br/>
			<input type="password" id = "pass" name="Password"><br/>
			<input type="submit" id = "btn" value="Submit!"><br/>
		</form>
	</body>
<footer>
<div class="footer">
<p>&copy Kathleen Bradshaw, Sam Disharoon, Mason Kimbell, Jordan Welch</p>
</div></footer>
</html>

