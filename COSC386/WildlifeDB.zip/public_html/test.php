<html>
<body>
<?php
if($connection=@mysqli_connect('localhost','mkimbell1','mkimbell1','mkimbell1DB')){
	//	print '<p>successfully connected to MySQL</p>';
	;
}else{
	die('<p>could not connect to MySQL</p>');
}

$query="SELECT ".$_POST["column"]." FROM Ships";
$r = mysqli_query($connection, $query);
	echo "<table border='1' align='center' cellpadding='15'>
		<thead>
		<tr>
		<th id=".$_POST["column"]."</th>".$_POST["column"]."
		</tr>
	</thead>";
while($row=mysqli_fetch_array($r)){
	echo"<tr style='background-color:#aaaaa0'>";
	echo"<td style='color:#ff0000'>".$row[$_POST["column"]]."</td>";
	echo"</tr>";
}
echo"</table>";
/*
echo "<br> testing below <br>";

function pog($a, $b){
	$c = $a + $b;
	return $c;
}

$c=pog(7,5);
echo $c;


print "hello world<br>";
echo "hello world"."a";
$foo = 3;
$bar = ($foo*2);
echo "<br>3*2=", $bar;

$counter=0;
while($counter<30){
	print "<p>hello php</p>";
	$counter += 1;
}
 */
mysqli_close($connection);
?>
</body>
</html>
