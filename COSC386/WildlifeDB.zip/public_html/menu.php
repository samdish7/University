<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="wildlife.css">
</head>
<body>
	<form method=post action="secure.php">
		<p>
			<input type="submit" id="btn" value="Insert Data"/></input>
		</p>
	</form>

	<form method=post action="showData.php">
		
			<input type="submit" id="btn" value="Show Data"/></input>
		</p>
	</form>
</body>
</html>
