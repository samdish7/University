<html>
<body>
<?php
if($connection=@mysqli_connect('localhost','mkimbell1','mkimbell1','WildLifeDB')){
	//	print '<p>successfully connected to MySQL</p>';
	;
}else{
	die('<p>could not connect to MySQL</p>');
}


$table = $_POST['table'];
//echo $table;
$insertData = $_POST['insertData'];
//echo "</br>".$insertData;

if($table == "Wildlife"){
	$attrList = "(lifespan, endangeredStatus, birthProcess, feedYoung, scientificName, size, commonName, population)";
}else if($table == "AquaticLife"){
	$attrList = "(aquaticID, vertebrae, type, scientificName)";
}else if($table == "Birds"){
	$attrList = "(wingspan, birdID, scientificName)";
}else if($table == "Mammals"){
	$attrList = "(mammalID, opposableThumbs, numLegs, scientificName)";
}else if($table == "Eats"){
	$attrList = "(predSName, preySName)";
}else if($table == "Location"){
	$attrList = "(region, habitat)";
}else if($table == "LivesIn"){
	$attrList = "(region, habitat, scientificName)";
}
//echo "</br>".$attrList;

$sql = "INSERT INTO ".$table." ".$attrList." VALUES (".$insertData.");";

//echo "</br>".$sql;

$rs = mysqli_query($connection, $sql);

if(mysqli_affected_rows($rs) == 0){
	echo "record inserted successfully";
}else{
	echo "error: could not insert ".$insertData." into ".$table.$attrList."</br>";
	echo "make sure your input is in the exact same format as the attributes of the table suggest</br>";
	echo "also make sure you put quotes around values that are type varchar </br>";
}
mysqli_close($connection);
?>

<form action="index.html">
		<p>
			<input type="submit" id="btn" value="Go Back"/></input>
		</p>
</form>

</body>
</html>
