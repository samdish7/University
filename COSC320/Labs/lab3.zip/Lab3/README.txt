				README FILE
				Sam Disharoon
A) Instead of passing an array, I just passed the struct in each parameter. Made things much easier. Pretty much just coded the suedo code you gave us and tested it well.
B) O(nlogn) best and worst
D) As n grows, the time gets longer and longer, however, it is insanely fast.The number of elements will in return make it go longer. However, Takes less than .001 seconds to sort a 1000 element array. Takes less than a second to sort and 800k element array.
F) I just tested random because Heapify will get them somewhat sorted anyway, but in a reverse order. So it always has a large workload against it. Worst case would be however in descending order.
G) If I could get printH (print heap) to work, that would be wonderful. This is however the most efficent sorting method we have covered so far. And it isn't even close.
