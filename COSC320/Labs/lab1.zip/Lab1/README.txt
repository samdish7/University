a) BubbleSort is best case O(N) Worst Case O(N^2)
SelectionSort is best case O(N^2) and worst case O(N^2)
InsertionSort is best case O(N) and worst case O(N^2)

b) The number of elements greatly determines the speed of the sorting algorithms. An array that is sorted with a million elements will still have to take time to go through those elements at least once. So it will take more time than a non sorted array that is only 50 elements. You can use this data to back up your time complexity.
d) The best case is the already sorted array, the worst case is the descending order array.
e) The code was already improved from Lab 6 last semester, but it could be improved even more by using quicksort or mergesort instead of the 3 above.
