README
Sam Disharoon

a.)My approach to the problem was to implement some of the processes from Lab 3 and implement them to this lab, but I couldn't figure out how to create a heap. I will be seeing you in your office.
b.)Not sure, doesn't work.
c.)Not sure, doesn't work.
d.)Priority queues would be helpful with cases such as emergency rooms if a patient comes in and is about to die, they would need more attention than someone with a minor injury.  Resturants need them in case a very important person comes in, or they messed up a table's food and need it before the other tables to make them happy.
e.)There are alot of ways to improve my code. Firstly by making sure the functions actually work. Secondly by actually implementing them to work.
