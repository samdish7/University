//Lab 4
//Sam Disharoon
//main.cpp
#include<iostream>
#include"priorityQ.h"
#include<time.h>
#include<string.h>
int main(){
	
	HeapQ h;
	h.insert("Sam", 10);
	h.insert("Bob",3);
	h.print();
return 0;
}
