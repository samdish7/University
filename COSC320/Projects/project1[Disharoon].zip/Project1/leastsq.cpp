//Project 1
//leastsq.cpp
//Sam Disharoon
#include"matrix.h"
#include<iostream>
#include<fstream>

int main(int argc,char** argv){


return 0;
}
